cd docs
doxygen
cd latex
make pdf
cd ../html
firefox index.html &
