cd build
make Demo_main1
cd ..
./build/tests/Demo_main1
