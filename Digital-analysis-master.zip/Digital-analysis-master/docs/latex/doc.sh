cd ..
doxygen
cd latex
make pdf
