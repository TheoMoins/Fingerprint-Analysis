#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <iostream>
#include "starter3.h"
#include "starter_1.h"
#include <math.h>
#include "Rotation.h"
#include "main2.h"

#define PI 3.14159265

/**
@file main2.cpp
@brief Body for the functions of the Main course 2
@author Romain C.
*/
